<!DOCTYPE html>
<!-- Written by: Jean-Luc Desroches -->
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="DATA/style.css" />


<?php
  echo '<title>Forum - ' . $page_title . '</title>';
?>

<!--[if gte IE 9]>
  <style type="text/css">
    .gradient {
       filter: none;
    }
  </style>
<![endif]-->

</head>
<body>

<?php
  echo '<h3 id="header">Forum - ' . $page_title . '</h3>';
?>
