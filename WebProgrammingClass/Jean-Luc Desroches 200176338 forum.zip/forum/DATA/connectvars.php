<?php
  // Define database connection constants
	define('DB_HOST','webdesign4.georgianc.on.ca');
	define('DB_USER','db200176338');
	define('DB_PASSWORD','99939');
	define('DB_NAME','db200176338');
?>
