  <hr />
  <p class="footer">Copyright &copy;2013 JLD Co.</p>
</body>
</html>
